"use client";
import LazyLoadedVideoNew from "@/components/Video2/LazyLoadedVideoNew";
import { BannerProps } from "@/@types/type";
import BookingForm from "@/components/BookingForm";
import { Container, Section } from "@/components/sectionComponants";
import SwiperCarousel from "@/components/sliders/SwiperCarousel";
import { LazyLoadedVideo } from "@/components/Video2";

import Image from "next/image";
import { FC } from "react";
import { Autoplay } from "swiper/modules";
import NavBar2 from "@/components/navbar/NavBar2";

const Banner: FC<BannerProps> = ({
  images,
  videoSrc,
  thumbNail,
  title,
  subTitle,
  description,
  showBookingForm = false,
}) => {
  const hasImages = images && images.length > 0;
  const hasSingleImage = images && images.length === 1;

  return (
    <Section defaultPadding={false} className="banner max_screen_width-2 ">
      {/* ✅ Case 1: Both Video + Images */}
      {videoSrc && hasImages ? (
        <div className="w-full max-w-[90rem] mx-auto grid grid-cols-1 md:grid-cols-5 gap-6 lg:py-12">
          <div className="w-full lg:h-dvh relative aspect-[4/3] md:col-span-3">
            <LazyLoadedVideo
              poster={thumbNail || ""}
              src={videoSrc}
              loop
              autoPlay
              muted
              controls={false}
            />

          </div>
          {/* <div className="lg:hidden block">
            <Swiper
              className="w-full h-dvh"
              spaceBetween={0}
              slidesPerView={1}
              loop={true}
              autoplay={{ delay: 2000 }}
              modules={[Autoplay]}
            >
              <SwiperSlide>
                <YoutubePlayer
                  poster={thumbNail || ""}
                  url={videoSrc}
                  youtubeUrl={videoSrc}
                  title={title || ""}
                />
              </SwiperSlide>
              <SwiperSlide className="w-full relative aspect-[4/3]">
                <Image
                  src={images[0]}
                  alt="image"
                  fill
                  className="object-cover"
                />
              </SwiperSlide>
            </Swiper>
          </div> */}
          <div className="md:col-span-2 flex flex-col gap-6 max-lg:px-4">
            <div className="">
              {title && <h1 className="text-lg">{title}</h1>}
              {subTitle && (
                <h2 className="text-lg md:text-[4rem] font-anton">
                  {subTitle}
                </h2>
              )}
              {description && <p className="md:text-lg mt-10">{description}</p>}
            </div>
            {/* {hasSingleImage ? ( */}
            <div className="w-full  relative aspect-[4/3]">
              <Image
                src={images[0]}
                alt="image"
                fill
                className="object-cover"
              />
            </div>
            {/* ) : (
              <SwiperCarousel
                data={images}
                slidesPerView={1}
                spaceBetween={0}
                loop
                modules={[Autoplay, Pagination]}
                pagination={{ clickable: true }}
                autoplay={{ delay: 2500 }}
                className="w-full"
                renderSlide={(image) => (
                  <div className="w-full relative aspect-[4/3]">
                    <Image
                      src={image}
                      alt="image"
                      fill
                      className="object-cover"
                    />
                  </div>
                )}
              />
            )} */}
          </div>
        </div>
      ) : /* ✅ Case 2: Only Video */
      videoSrc ? (
        <div className="w-full xl:h-dvh max-xl:aspect-4/3 max-lg:aspect-[4/2] max-md:aspect-[3/4.5] relative">
          <LazyLoadedVideoNew src={videoSrc} poster={thumbNail || ""} />
          <div className="absolute top-0 left-0 w-full z-10">
            <NavBar2 />
          </div>
          {showBookingForm && (
            <div className="absolute bottom-6 inset-x-0 ">
              <Container className="xl:max-w-5xl! mx-auto">
                <BookingForm />
              </Container>
            </div>
          )}
        </div>
      ) : /* ✅ Case 3: Only Single Image */
      hasSingleImage ? (
        <div className="w-full xl:h-dvh max-xl:aspect-4/3 max-lg:aspect-[4/2] max-md:aspect-[3/4.5] relative">
          <Image
            src={images[0]}
            alt="banner image"
            fill
            priority
            className="object-cover"
          />

          <div className="absolute top-0 left-0 w-full z-10">
            <NavBar2 />
          </div>
          {showBookingForm && (
            <div className="absolute bottom-6 inset-x-0 z-10">
              <Container className="xl:max-w-5xl! mx-auto">
                <BookingForm />
              </Container>
            </div>
          )}
        </div>
      ) : /* ✅ Case 4: Multiple Images (Carousel) */
      hasImages ? (
        <div className="relative w-full max_screen_width">
          <SwiperCarousel
            data={images}
            slidesPerView={1}
            spaceBetween={0}
            loop
            modules={[Autoplay]}
            autoplay={{ delay: 3000 }}
            speed={2500}
            className="w-full"
            renderSlide={(image) => (
              <div className="w-full xl-[3/1.5] max-xl:aspect-[3.2/1.7] lg:aspect-[3.2/1.5] max-md:aspect-[4/6] md:aspect-[4/5]  relative">
                <Image
                  src={image}
                  alt="banner image"
                  fill
                  className="object-cover"
                />
                <div className="absolute inset-0 z-1 bg-black/20" />
              </div>
            )}
          />
          <div className="bg-background-2 w-full overflow-hidden">
            <Image
              src="/images/Greek1.png"
              alt=""
              width={1440}
              height={80}
              className="h-auto w-full object-cover"
            />
          </div>

          {/* <div className="absolute top-0 left-0 w-full z-10">
            <NavBar2 />
          </div> */}
          {showBookingForm && (
            <div className="absolute bottom-6 inset-x-0 z-10">
              <Container className="xl:max-w-5xl! mx-auto">
                <BookingForm />
              </Container>
            </div>
          )}
        </div>
      ) : null}
    </Section>
  );
};

export default Banner;
