import { DiamondIcon, Dining, LocalInsight, Secure } from "@/utils/webicons";

export const OurStoryData = {
  about: {
    title: "First-Class Selection Of Luxury Villas And Apartment",

    logo: "/images/cropped-iconlogo.png",

    sectionTitle: "About Us",

    description:
      "Aroha Palms is a hospitality brand and property operated by Akahata Hospitality Private Limited, a company incorporated in India. All bookings, payments, and guest services are provided by Akahata Hospitality Private Limited.",

    details: [
      {
        label: "GST",
        value: "30AAXCA4249B1ZV",
      },
      {
        label: "CIN",
        value: "U55101GA2022PTC015434",
      },
      {
        label: "Registered Address",
        value:
          "House No.211/1-A 7, B-704, Block B, Sancoale, Zuari Nagar, Vasco Da Gama, South Goa",
      },
    ],
  },
  missionData: {
    title: "Our Mission",

    intro:
      "At Aroha Palms, we craft unforgettable stays in Goa where refined living, intuitive service, and thoughtfully curated moments come together to create experiences that linger long after you leave.",

    description: [
      "Refined luxury, elevated hospitality, and 24/7 personalized service ensuring a seamless, comfortable, and indulgent stay.",

      "The core of Aroha Palm's philosophy is simply luxury whilst blending elegance with comfort rather than opulence. Our accommodation are set in a luxurious tone, and designed to complement the Goan setting.",
    ],

    images: [
      "/images/villa-paradiso-1424e9.webp",
      "/images/DSC00046-Edit-1-scaled-1.jpg",
      "/images/villa-serenity-49921f.webp",
      "/images/sde3.webp",
      "/images/sde8.webp",
    ],
  },
  // villasData :{
  //   title: "Our Villas",

  //   description: [
  //     "Our villas are situated in such a manner that they seamlessly blends indoor and outdoor living spaces to create an atmosphere of old-world charm.",

  //     "With manicured garden, private pool, and multiple bedrooms, we aim to provides the perfect retreat for relaxation in a natural setting.",

  //     "The outdoor patio, overlooking the crystal blue waters of the pool, provides a tranquil and comfortable space for unwinding.",

  //     "Indulge in a stay where every desire is anticipated, and every detail is effortlessly taken care of.",
  //   ],

  //   card: {
  //     title:
  //       "Discover a way for family and friends to vacation better together.",

  //     description:
  //       "At Aroha Palms, every stay is designed for togetherness. From slow mornings by the pool to evenings that linger a little longer, our homes create the perfect setting for families and friends to reconnect, celebrate, and simply be.",
  //   },
  // },
  villasData: {
    title: "Our Villas",

    description: [
      "Our villas are situated in such a manner that they seamlessly blends indoor and outdoor living spaces to create an atmosphere of old-world charm.",

      "With manicured garden, private pool, and multiple bedrooms, we aim to provides the perfect retreat for relaxation in a natural setting.",

      "The outdoor patio, overlooking the crystal blue waters of the pool, provides a tranquil and comfortable space for unwinding.",

      "Indulge in a stay where every desire is anticipated, and every detail is effortlessly taken care of.",
    ],
    videos: [
      {
        video: "",
        thumbnail: "/villa-1.png",
      },
      {
        video: "",
        thumbnail: "/villa-2.png",
      },
    ],

    card: {
      title:
        "Discover a way for family and friends to vacation better together.",

      description:
        "At Aroha Palms, every stay is designed for togetherness. From slow mornings by the pool to evenings that linger a little longer, our homes create the perfect setting for families and friends to reconnect, celebrate, and simply be.",
    },
    buttons: [
      {
        label: "Explore Mandrem",
        href: "/mandrem",
        variant: "solid",
      },
      {
        label: "Explore Pilerne",
        href: "/pilerne",
        variant: "outline",
      },
    ],
  },
  confidenceData: {
    title: "Driven By Confidence, Elegance And Luxury",

    features: [
      {
        icon: <DiamondIcon />,
        title: "Refined Stays",
        description:
          "Thoughtfully designed spaces that bring together comfort, privacy, and understated luxury.",
      },
      {
        icon: <Dining />,
        title: "Tailored Service",
        description:
          "Attentive, intuitive service shaped around your every need.",
      },
      {
        icon: <LocalInsight />,
        title: "Local Insight",
        description:
          "Curated recommendations to help you experience Goa beyond the usual.",
      },
      {
        icon: <Secure />,
        title: "Trusted Approach",
        description:
          "Clear, honest experiences built on reliability and lasting trust.",
      },
    ],

    gallery: [
      "/images/sde10.webp",
      "/images/AOB_3223.jpg",
      "/images/20-Seating-area-2-1024x683.jpg",
      "/images/AOB_3585-scaled.jpg",
      "/images/AOB_3733-scaled.jpg",
      "/images/villa-serenity-be9006.jpg",
      "/images/dinning 1.jpg",
      "/images/DSC00056-Edit-scaled-1.jpg",
      "/images/AOB_0164.jpg",
    ],
  },
};
