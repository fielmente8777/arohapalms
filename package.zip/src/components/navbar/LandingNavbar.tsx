"use client";
import Image from "next/image";
import Link from "next/link";
import { BookingCalenderIcon } from "@/utils/formIcons";
import { navData } from "./navData";
import { useWebContext } from "@/context-api/WebContext";

const LandingNavbar = () => {
  // const scrollToSection = (id: string) => {
  //   const element = document.getElementById(id);
  //   if (element) {
  //     element.scrollIntoView({ behavior: "smooth" });
  //   }
  //   return;
  // };
  const { openFormPopUp , isOpen, closeRoom} = useWebContext();

  return (
    <header className="max_screen_width w-full">
      {/* TOP BAR */}
      <nav className="max_width">
        <div className="flex py-4 w-full items-center justify-between">
          {/* LOGO */}
          <div>
            <div className="relative aspect-[4/.9] w-40 md:w-75">
              <Image
                src={navData.logo}
                alt="Logo"
                fill
                priority
                className="object-cover rounded-md"
              />
            </div>
          </div>
          {/* nav */}
          {/* <ul className="lg:flex border hidden border-white/15 bg-white/10 backdrop-blur-lg  rounded-full items-center  ml-36 w-fit nav">
            {navData.links.map((link, index) => (
              <li key={index}>
                <button
                  onClick={() => scrollToSection(link.href)}
                  type="button"
                  className="text-white px-5 py-2.5 "
                >
                  {link.label}
                </button>
              </li>
            ))}
          </ul> */}
          {/* BUTTON */}
          <ul className="flex items-center gap-2">
            {navData.buttons.map((link, index) => (
              <li key={index} className="flex items-center gap-2">
                <button
                  onClick={() => {
                    openFormPopUp();
                  }}
                  // href={link.href}
                  // target="_blank"
                  // rel="noopener noreferrer"
                  className="flex items-center gap-2 rounded-lg bg-primary uppercase text-white px-2 md:px-6 py-2 md:py-3"
                >
                  <span className="">
                    <BookingCalenderIcon />
                  </span>
                  <span className="lg:block text-base hidden tracking-widest font-semibold">
                    BOOK NOW
                  </span>
                </button>
              </li>
            ))}
          </ul>
        </div>
      </nav>
    </header>
  );
};

export default LandingNavbar;
